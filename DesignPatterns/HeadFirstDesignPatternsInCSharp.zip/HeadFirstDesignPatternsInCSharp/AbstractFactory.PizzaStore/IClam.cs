using System;

namespace HeadFirstDesignPatterns.AbstractFactory.PizzaStore
{
	/// <summary>
	/// Summary description for IClams.
	/// </summary>
	public interface IClams
	{
		string toString();
	}
}
